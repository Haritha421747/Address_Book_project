/*NAME:G.HARITHA
DATE:19/9/24
DESCRIPTION:CREATING ADDRESS BOOK
SAMPLE INPUT & OUTPUT:*/
Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 1
Enter the name:hari134
Invalid name enter name should alphabets only
Enter the name:haritha
Enter the phone:98667gh
Invalid phone number contais only digits
Enter the phone:9398564598
Enter the email:hari@.com
Invalid email
Enter the email:haritha@gmail.com

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 5
1.A-Z order
2.Z-A order
3.normal order
please enter the option:1
name:bhavana
phone:9177238945
email:bhavana@gmail.com
name:haritha
phone:9398564598
email:hari@.com
name:hari
phone:8333083890
email:haritha@gmil.com
name:haritha
phone:9398564598
email:haritha@gmail.com
name:pooja
phone:1230987654
email:pooja@g.com
name:pooji
phone:0978674589
email:poiogjhhg@g.com

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 2
Enter the name:harithaaaa
Contact not found

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: pooja
Enter the name:pooja
1230987654
pooja@g.com
Contact found

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 3
1.name
2.phone
3.email
enter the option you wanted to edit:1
Enter the old name:pooja
Enter the new name:poojithaa
Edited neme successfully

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 3
1.name
2.phone
3.email
enter the option you wanted to edit:1
Enter the old name:harithaaaaaaaaa
invalid input try again

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 3
1.name
2.phone
3.email
enter the option you wanted to edit:2
Enter the old phone number:9398564598
Enter the new phone number:9498564597
Edited mobile number successfully

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 3
1.name
2.phone
3.email
enter the option you wanted to edit:2
Enter the old phone number:9398564598
invlaid input try again

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 3
1.name
2.phone
3.email
enter the option you wanted to edit:3
Enter the old email :bhavana@gmail.com
Enter the new email :bhavana123@gmail.com
Edited email successfully
Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 3
1.name
2.phone
3.email
enter the option you wanted to edit:3
Enter the old email :bhavana@gmail.com
invalid input try again

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 4
Enter the name::pooji
invalid input try again

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 4
Enter the name:pooji
Contact delete successfully

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 1
Enter the name:harithachowdary
Enter the phone:9494375060
Enter the email:harithachowdary0101@gmail.com

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 6
Saving and Exiting...
Contact succesfully saved

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 5
1.A-Z order
2.Z-A order
3.normal order
please enter the option:2
name:poojithaa
phone:1230987654
email:pooja@g.com
name:haritha
phone:9498564597
email:hari@.com
name:hari
phone:8333083890
email:haritha@gmil.com
name:harithachowdary
phone:9494375060
email:harithachowdary0101@gmail.com
name:bhavana
phone:9177238945
email:bhavana123@gmail.com

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save contacts
7. Exit
Enter your choice: 7
Invalid choice. Please try again.