#ifndef FILE_H
#define FILE_H

#include "contact.h"

int saveContactsToFile(AddressBook *addressBook);
int loadContactsFromFile(AddressBook *addressBook);

#endif
