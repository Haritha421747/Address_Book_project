#include <stdio.h>
#include "file.h"
//funtion declaraction of save contact files
int saveContactsToFile(AddressBook *addressBook)
{
    //open the file in write collect address in pointer fptr
    FILE *fptr=fopen("contacts.txt","w");
    //check address return null or not
    if(fptr==NULL)
    {
        printf("FILE NOT EXIST\n");
        return 1;
    }
    //read contact from addressbook write to fptr
    fprintf(fptr,"%d\n",addressBook->contactCount);
    //run a loop contactcount times
    for(int i=0;i<addressBook->contactCount;i++)
    {
        //write contact details to fptr
        fprintf(fptr,"%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }
    //close the fptr file
    fclose(fptr);
    //prompt user
    printf("Contact succesfully saved\n"); 
}
//function defintion for load contacts
int loadContactsFromFile(AddressBook *addressBook)
{
    //open file in read mode collect addresss in pointer fptr
    FILE *fptr=fopen("contacts.txt","r");
    //check adresss null or not
    if(fptr==NULL)
    {
        printf("FILE NOT EXIST\n");
        return 1;
    }
    //intialize count 0
    int count=0;
    //read count from the file
    fscanf(fptr,"%d\n",&count);
    //store count in adddressbook count
    addressBook->contactCount=count;
    // check count 
    if(count != 0)
    {
        //run a loop count times
        for(int i=0;i<count;i++)
        {
            //read contact details from the file
            fscanf(fptr,"%[^,],%[^,],%[^\n]\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        }
    }
    else
    {
        printf("NO CONTACT PRESENT IN THE FILE\n");
    }
    //close the file
    fclose(fptr);  
}
