#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"
#include "file.h"
#include "populate.h"
//function defintion for list contacts
void listContacts(AddressBook *addressBook)
{
    // Sort contacts based on the chosen criteria
    //declaraction
    int option;
    //prompt user which order want to print
    printf("1.A-Z order\n2.Z-A order\n3.normal order\n");
    printf("please enter the option:");
    //read option from user
    scanf("%d",&option);
    //passing the option
    switch(option)
    {                                                                              //if option is 1 printing from A-Z
        case 1:
        {
            char ch='A',ch1='a';                                                      //check condition
            while(ch<='Z')
            {
                for(int i=0;i<addressBook->contactCount;i++)                         //run  a loop upto conctact count   
                {
                    char ptr[50];
                    strcpy(ptr,addressBook->contacts[i].name);
                    if(ptr[0]==ch || ptr[0]==ch1)                                    //check the condition
                    {
                        printf("name:%s\n",addressBook->contacts[i].name);           //printing the contact details
                        printf("phone:%s\n",addressBook->contacts[i].phone);
                        printf("email:%s\n",addressBook->contacts[i].email);
                    }
                }
                ch++;
                ch1++;
            }
            break;
        }
        case 2:                                                                      //if option is 2 printing fron Z-A
        {
            char ch='Z',ch1='z';                                                     //check from Z-A
            while(ch>='A')
            {
                for(int i=0;i<addressBook->contactCount;i++)                         //run a loop upto contactcount
                {
                    char ptr[50];
                    strcpy(ptr,addressBook->contacts[i].name);
                    if(ptr[0]==ch || ptr[0]==ch1)                                   //check the condition printing the contactdetails
                    {
                        printf("name:%s\n",addressBook->contacts[i].name);
                        printf("phone:%s\n",addressBook->contacts[i].phone);
                        printf("email:%s\n",addressBook->contacts[i].email);
                    }
                }
                ch--;
                ch1--;
            }
            break;
        }
        case 3:                                                                  //if option normal order
        {
            for(int i=0;i<addressBook->contactCount;i++)                         //run a upto contactcount
            {
                printf("name:%s\n",addressBook->contacts[i].name);                //printing all contacts in normal order
                printf("phone:%s\n",addressBook->contacts[i].phone);
                printf("email:%s\n",addressBook->contacts[i].email);
            }
            break;
        }
        default:                                                                  //if option is not there print invaild
        {
            printf("invalid input try again\n");
        }
    }
}
//function defintion intilize contact
void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;                                              //intialize count as 0
    //populateAddressBook(addressBook);
    
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}
//function defintion for save and exit contact
void saveAndExit(AddressBook *addressBook)
{
    //declaration
    char op;
    //prompt user
    printf("Are you want save contact or not Y/N:");
    //read the value from user
    scanf("%c",&op);
    //based on condition to call the save contact 
    if(op=='Y'||op=='y')
    {
        saveContactsToFile(addressBook);
    }
     // Save contacts to file
     else
     {
        exit(EXIT_SUCCESS);
     }
        //exit(EXIT_SUCCESS); // Exit the program
}
//function definition create contact
void createContact(AddressBook *addressBook)
{
	/* Define the logic to create a Contacts */
    //declaration array for name,phone,email
    char NAME[100];
    char PHONE[11];
    char EMAIL[40];
    label1:
    //prompt user
    printf("Enter the name:");
    //read name from user
    scanf(" %[^\n]",NAME);
    //read only character from array
    getchar();
    //intailize i with 0
    int i=0;
    //check the condition for upto null
    while(NAME[i]!=0)
    {
        //condition for name consist alphabets or not
	   if(isalpha(NAME[i])!=0 ||  NAME[i]==' ') 
       {
           //if name contains alphabets name copy to address book
           strcpy(addressBook->contacts[addressBook->contactCount].name,NAME);  
       }
       //if name contains any characters apart from alphabet print error again goto label1
       else
       {
           printf("Invalid name enter name should alphabets only\n");
           goto label1;
       }
       i++;
    }
    label2:
    //prompt user
    printf("Enter the phone:");
    //read number from user
    scanf(" %[^\n]",PHONE);
    //to read new line from stdin
    getchar();
    i=0;
    //check condition upto null
    while(PHONE[i]!=0)
    {
        //check condition mobile consist all digits or not and length 10
		if(isdigit(PHONE[i])!=0 && PHONE[i]!=' ' && strlen(PHONE)==10)
        {
            //if condition true mobile number copy to addressbook
            if(strcmp(PHONE,addressBook->contacts[i].phone)!=0)
            {
                strcpy(addressBook->contacts[addressBook->contactCount].phone,PHONE);
            }
        } 
        //prints invalid number againgoto label2
        else
        {
            printf("Invalid phone number contais only digits\n");
            goto label2;
        }
        i++;
    }
    label3:
    //prompt user
    printf("Enter the email:");
    //read email from user
    scanf(" %[^\n]",EMAIL);
    //to read new line from stdin
    getchar();
    i=0;
    //declaration
    char str_mail[]=".com";
    char *ret_mail;
    char *ret_mail1;
    //compare email with .com returns address store in re_mail
    ret_mail=strstr(EMAIL,str_mail);
    //check condition ret_mail is null or not.if not read again
    if(ret_mail == NULL)
    {
        printf("Enter again\n");
        goto label3;
    }
    //compare email with @ or not return adrress store in re_mail1
    ret_mail1=strchr(EMAIL,'@');
    //check condition ret_mail is null or not.if not read again
    if(ret_mail1 == NULL)
    {
        printf("Invalid email id,enter again\n");
        goto label3;
    }
    //check condition after @ present atleast one character or not
    if((isalpha(ret_mail1[1]))==0)
    {
        printf("Invalid email\n");
        goto label3;
    }
    //check the condition email upto null
    while(EMAIL[i]!=0)
    {
        //copy emailto the addressbook
        strcpy(addressBook->contacts[addressBook->contactCount].email,EMAIL);
        i++;
    }
    //after adding the contact details increment by 1
    addressBook->contactCount++;
}
//function definition of sreach contact
void searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
    //declare array
   char str[100];
   //prompt user
   printf("Enter the name:");
   //read name from user
   scanf(" %[^\n]",str);
   //declare variables
   int m=0,flag,j;
   //run a loop upto adressbook
   for(int i=0;i<addressBook->contactCount;i++)
   {
    //compare name with all contacts name in the structure
       if(strcmp(str,addressBook->contacts[i].name)==0)
       {
        //if name present in adressbook make flag as one ,increment m by 1 ,store i in j
           flag=1;
           m++;
           j=i;
        }
   }
    if(flag==1)
    {
        if(m==1)
        {
            flag=0;
        }
        else
        {
            //same name present more than one time confirm the mobile number
            printf("list consist same names enter number to verify\n");
            //declare string
            char str1[20];
            //read mobile number number from user
            scanf(" %[^\n]",str1);
            //run a lopo upto contact count
            for(int i=0;i<addressBook->contactCount;i++)
            {
                //compare mobile number with address book mobile number
                if(strcmp(str1,addressBook->contacts[i].phone)==0)
                {
                    //if mobile number present than make flag as 2
                    j=i;
                    flag=2;
                    break;
                }
                else
                {
                  flag=1;
                }
            }
        }
        //based on flag give contactdetails to user
        if(flag==0 || flag==2)
        {
            printf("%s\n",addressBook->contacts[j].name);
            printf("%s\n",addressBook->contacts[j].phone);
            printf("%s\n",addressBook->contacts[j].email);
        }
        printf("Contact found\n");
    }
    //not present give invalid input
    else
    {
        printf("Contact not found\n");
    }
}
//function defintion to editcontact
void editContact(AddressBook *addressBook)
{
    /* Define the logic for search */
    //declaration
    int option;
    //prompt user select one option
    printf("1.name\n2.phone\n3.email\n");
    //prompt user edit based on
    printf("enter the option you wanted to edit:");
    //read option from user
    scanf("%d",&option);
    //if option 1
    switch(option)
    {
        //which name want to edit inthe addressbook
        case 1:
        {
            //declare string
            char str[100];
            //prompt user
            printf("Enter the old name:");
            //read name from the user
            scanf(" %[^\n]",str);
            //declare and intailizee variables
            int flag=0,m=0,j;
            //run a loop upto contactcount
            for(int i=0;i<addressBook->contactCount;i++)
            {
                //compare name with address book name
                if(strcmp(str,addressBook->contacts[i].name)==0)
                {
                    //if name present in adressbook make flag as one ,increment m by 1 ,store i in j
                    m++;
                    j=i;
                    flag=1;
                }
            }
            if(flag==1)
            {
                if(m==1)
                {
                    flag=0;
                }
                else
                {
                    //same name present more than one time confirm the mobile number
                    printf("list consist same user name enter number to verify:");
                    //read mobile number number from user
                    char str2[20];
                    scanf(" %[^\n]",str2);
                    //run a lopo upto contact count
                    for(int i=0;i<addressBook->contactCount;i++)
                    {
                        //compare mobile number with address book mobile number
                        if(strcmp(str2,addressBook->contacts[i].phone)==0)
                        {
                            //if mobile number present than make flag as 2
                            j=i;
                            flag=2;
                            break;
                        }
                        else
                        {
                            flag=1;
                        }
                    }
                }
                //based on flag value to edit new inthe addressbook
                if(flag==0 || flag==2)
                {
                    //declare string
                    char str1[100];
                    //prompt user
                    printf("Enter the new name:");
                    //read string from user
                    scanf(" %[^\n]",str1);
                    //copy new name to addressbook
                    strcpy(addressBook->contacts[j].name,str1);
                }
                printf("Edited neme successfully\n");
            }
            //print invalid input
            else
            {
                printf("invalid input try again\n");
            }
            break;
        }
        case 2:
        {
            //declare string
            char str[100];
            //prompt user
            printf("Enter the old phone number:");
            //read number from user
            scanf(" %[^\n]",str);
            //intilize variables
            int flag=0,m=0;
            //run a loop upto addressbookcount
            for(int i=0;i<addressBook->contactCount;i++)
            {
                //mobile number with addressbook mobilenumber
               if(strcmp(str,addressBook->contacts[i].phone)==0)
               {
                //if mobile number present than make flag as 2
                    m=i;
                    flag=1;
                    break;
               }
                else
                {
                    flag=0;
                }
            }
            //based on flag value enter new phone number
            if(flag==1)
            {
                //declaration of string
                char str1[100];
                //prompt user
                printf("Enter the new phone number:");
                //read number from user
                scanf(" %[^\n]",str1);
                //intailise with 0
                int j=0;
                //check condition mobile number upto null
                while(str1[j])
                {
                    //enter string digit or not
                    if(isdigit(str1[j])!=0)
                    {
                        flag=0;
                    }
                    //not contain flag as 1 and the break loop
                    else
                    {
                        flag=1;
                        break;
                    }
                    j++;
                }
                //based on flag value check the condition
                if(flag==0)
                {
                    //intailize mobile number count with 0
                    int ret=0;
                    //chek the condition  the get length
                    while(str1[ret])
                    {
                        ret++;
                    }
                    //check condition length equal 10 or not 
                    if(ret==10)
                    {
                        //run a loop upto addressbook count
                        for(int i=0;i<addressBook->contactCount;i++)
                        {
                            //compare number witha all contact number
                            if(strcmp(str1,addressBook->contacts[i].phone)!=0)
                            {                                          
                                flag=3;
                            }
                            else
                            {
                                flag=4;
                                break;
                            }
                        }
                        //if the number present in structure edit that number
                        if(flag==3)
                        {
                            strcpy(addressBook->contacts[m].phone,str1);
                            printf("Edited mobile number successfully\n");
                        }
                        //if not present read again
                        else
                        {
                            printf("already existed number try again\n");
                            editContact(addressBook);
                        }
                    }
                    //the number contains only 10 digits 
                    else
                    {
                        printf("number should have 10 digit try again\n");
                        editContact(addressBook);
                    }
                }
                //the number contains only 0-9 digits
                else
                {
                    printf("number should consist only digits (0-9) try again\n");
                    editContact(addressBook);
                }
            }
            //user enter apart from 10 digits print invaild input
            else
            {
                printf("invlaid input try again\n");
            }
            break;
        }
        case 3:
        {
            //declare string
            char str[100];
            //prompt user
            printf("Enter the old email :");
            //read mail from user
            scanf(" %[^\n]",str);
            //declaration
            int flag=0,m;
            //run a loop upto addressbook contact count
            for(int i=0;i<addressBook->contactCount;i++)
            {
                //compare email with adressbook emiail id
                if(strcmp(str,addressBook->contacts[i].email)==0)
                {
                    m=i;
                    flag=1;
                    break;
                }
                else
                {
                    flag=0;
                }
            }
            //if the flag is 1 enter the new email to edit
            if(flag==1)
            {
                //declare
                char str1[100];
                //prompt user
                printf("Enter the new email :");
                //read emaild from user
                scanf(" %[^\n]",str1);
                //copy email to address book
                strcpy(addressBook->contacts[m].email,str1);
                printf("Edited email successfully");
            }
            //print invaild input
            else
            {
                printf("invalid input try again\n");
            }
            break;
        }
        //entered option is not matched print invaild input
        default :
        {
            printf("invalid input\n");
        }
    }
}
//function defintion for deletecontact
void deleteContact(AddressBook *addressBook)
{
	/* Define the logic for deletecontact */
    //declare string
    char str[100];
    //prompt user
    printf("Enter the name:");
    //read neme from user
    scanf(" %[^\n]",str);
    int flag=0,m=0,j;
    //run a loop upto addresscount
    for(int i=0;i<addressBook->contactCount;i++)
    {
        //compare enterd name with addressbook name
        if(strcmp(str,addressBook->contacts[i].name)==0)
        {
            //if the nmae present flaag as 1,store i value in j
            m++;
            flag=1;
            j=i;
        }
    }
    if(flag==1)
    {
        if(m==1)
        {
            flag=1;
        }
        else
        {
            //if the contact found same name confrim with mobile number
            printf("list consist same names enter number to verify\n");
            //declare string
            char str1[20];
            //read mobile number from user
            scanf(" %[^\n]",str1);
            //run a loop upto contactcount
            for(int i=0;i<addressBook->contactCount;i++)
            {
                //compare enter mobile number with adressbook mobile number
                if(strcmp(str1,addressBook->contacts[i].phone)==0)
                {
                    //if mobile number present than make flag as 2
                    j=i;
                    flag=2;
                    break;
                }
                else
                {
                    flag=1;
                }
            }
        }
        //based on flag value delete the contact from the structure
        if(flag==1 || flag==2)
        {
            //run loop upto contactcount times
            for(int i=j;i<addressBook->contactCount;i++)
            {
                //shifting all after deletion of contact
                strcpy(addressBook->contacts[i].name,addressBook->contacts[i+1].name);
                strcpy(addressBook->contacts[i].phone,addressBook->contacts[i+1].phone);
                strcpy(addressBook->contacts[i].email,addressBook->contacts[i+1].email);
            }
            //decrement addressbook count after deletin
            addressBook->contactCount--;
        }
        //prompt user
        printf("Contact delete successfully\n");
    }
    //if contact is not present print invalid input
    else
    {
        printf("invalid input try again\n");
    } 
}
